#!/bin/bash

SYNC="news linux talk sci humanities comp rec soc misc";

cd /home/nntpsucka

LOCKFILE=.synclock
STARTFILE=start-silent.sh

test -f $LOCKFILE && echo "`date`: $LOCKFILE exists" && exit 1;
GS=`date +%s`
echo "$GS" > $LOCKFILE;



echo -n "$0: ";
for GROUP in ${SYNC}; do echo -n "${GROUP} "; done;
echo " !";

for GROUP in ${SYNC}; do
 pidfile="nntpsucka_${GROUP}.pid";
 echo -n "`date +%s`:`date` ${pidfile}? ";
 i=0
 start=0
 while [ -f ${pidfile} ]; do
  test $i -gt 5 && echo "${GROUP} timeout" && break
  echo -n "$i "; let i="i+1"; sleep 1;
 done;
 test ! -f ${pidfile} && echo -n "no" && start=1;
 if test $start -eq 1; then
  #echo " DEBUG ./${STARTFILE} ${GROUP}"
  if test ! -x ${STARTFILE}; then
   echo "${STARTFILE} not executable";
   exit 1;
  else
   echo ": ./${STARTFILE} ${GROUP}" && ./${STARTFILE} ${GROUP};
   wait=0
   while [ ! -f ${pidfile} ]; do
    test $wait -gt 5 && break;
    sleep 1; let wait="wait+1";
   done;
   test ! -f ${pidfile} && echo "started but ${pidfile} not detected, break" && break;
   wait=0;
   while  [ -f ${pidfile} ]; do
    test $wait -gt 60 && echo " ${GROUP} took too long, break" && break;
    sleep 1;
    let wait="wait+1";
   done;
  fi;
 fi;
done;

rm -v $LOCKFILE
GE=`date +%s`
let RT="$GE - $GS"
echo " runtime: $RT seconds"
test ! -z $1 && test $1 = "loop" && $0 loop &
