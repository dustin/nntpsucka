#!/bin/bash
test -z "$1" && echo "usage: $0 group" && exit 1
cp -v sucka_template.conf "sucka_${1}.conf"
sed "s/template/${1}/g" -i "sucka_${1}.conf"
grep "${1}" "sucka_${1}.conf"
if [ ! -f "forcedList.${1}" ]; then
 echo "^${1}\." > "forcedList.${1}" && echo "created forcedList.${1}"
fi
exit 0
