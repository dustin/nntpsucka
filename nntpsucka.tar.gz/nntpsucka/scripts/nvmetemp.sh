watch "smartctl -a /dev/nvme0|grep -i temp"
