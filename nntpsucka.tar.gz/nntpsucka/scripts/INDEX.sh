find . -type f -printf "%p:%A@:%s\n" > INDEX.file;
