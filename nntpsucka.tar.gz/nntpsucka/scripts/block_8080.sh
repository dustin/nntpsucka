conntrack --flush
iptables -vI OUTPUT -d 81.171.88.0/21 -p tcp --dport 8080 -j REJECT
sleep 90
iptables -vD OUTPUT -d 81.171.88.0/21 -p tcp --dport 8080 -j REJECT
exit 0
