#!/bin/bash
cd /nntpsucka/||exit 1

LISTFILE="list-2019-thecubenet.txt";

REGEX_FILTER_FILE="globalfilter.txt"

REGEX_FILTER=".*test.*"

test ! -z $REGEX_FILTER_FILE && FILTER=`cat "${REGEX_FILTER_FILE}" | tr '\n' '|' | sed 's/|$//g'`;

test ! -z $REGEX_FILTER && FILTER="${REGEX_FILTER}"

FILTERED=`grep -E "${FILTER}" "${LISTFILE}" | sort -t" " -k2 -gr`;

FILTER_WC_L=`echo "$FILTERED"|wc -l`;

echo "$FILTERED" > filtered.txt;

ARTICLES=`cat filtered.txt | awk 'BEGIN {FS = " "} ; {sum+=$2} END {print sum}'`

echo "FILTER='$FILTER' ARTICLES=$ARTICLES, put $FILTER_WC_L groups to filtered.txt";
exit 0
