#!/bin/bash
#
SIZE=8G
if [ ! -e /mnt/ramfs/.mounted ]; then
	mount -v -t ramfs -o size=$SIZE ramfs /mnt/ramfs && mount |grep ramfs && \
		mkdir -vp /mnt/ramfs/newsdb && \
		touch /mnt/ramfs/.mounted && \
		chown -v nntpsucka /mnt/ramfs/newsdb && \
		rsync -va /mnt/TOS2T2/newsdb.ramfsbak/ /mnt/ramfs/newsdb/ && \
		mkdir -p /mnt/ramfs/logs/newscache && chown news:news /mnt/ramfs/logs/newscache && \
		ln -sfv /mnt/ramfs/logs/newscache/newscache-text.log /usr/local/opt/newscache-text/log/newscache.log && \
		/usr/local/opt/start_newscache.sh && \
		exit 0

echo "mounting ramfs failed or is mounted!"
exit 1
