#/bin/bash
test -z $1 && echo "usage: $0 300k" && exit 1
SIZE=$1
find . -type f -size +$SIZE -exec ls -lh {} \;
exit $?

