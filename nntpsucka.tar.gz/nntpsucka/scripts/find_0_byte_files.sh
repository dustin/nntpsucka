DEL=""
test ! -z $1 && test $1 = "-delete" && DEL="-print -delete"
find . -size 0 $DEL
