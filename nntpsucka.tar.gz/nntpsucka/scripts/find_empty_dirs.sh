find . -type d -empty -delete
