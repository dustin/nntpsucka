tail -f /mnt/ramfs/logs/newscache/newscache*
