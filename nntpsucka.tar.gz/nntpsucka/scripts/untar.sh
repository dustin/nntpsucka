tar xfvz $1.tar.gz -C /mnt/nntp/newscache/
