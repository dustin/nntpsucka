i=0; max=`ls -lha|wc -l`; while [ $i -lt $max ]; do let i="i+1"; test ! -f .art$i && echo "not found $i"; done
