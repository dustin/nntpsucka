watch -n 1 "tail -n 4 /mnt/ramfs/logs/newscache/newscache*"
