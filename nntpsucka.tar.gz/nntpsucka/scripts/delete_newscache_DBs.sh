find . -type f -iname "*.db" -print -delete
