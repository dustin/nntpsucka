test -f /mnt/ramfs/.mounted && rsync -va --progress /mnt/ramfs/newsdb/ /mnt/ST4T1/newsdb.ramfsbak/
