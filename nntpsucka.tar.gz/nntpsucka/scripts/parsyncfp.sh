parsyncfp  --maxload=5.5 --NP=4 --chunksize=$((1024 * 1024 * 4)) --startdir='/var/cache' newscache-5M root@209.141.55.183:/var/cache/newscache1/newscache-5M/
