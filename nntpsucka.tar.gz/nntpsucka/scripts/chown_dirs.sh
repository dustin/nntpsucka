#!/bin/bash
test ! -e "$1" && DIR=. || DIR=$1
test -e "$DIR" || DIR=.
echo "DIR=$DIR"
find "$DIR" -type d -exec chown -v news:news {} +
