#!/bin/bash
S=/sizes/sizes.txt; 
DIR=/var/cache/newscache-text; 
while read dir; do 
	echo "`date`: $dir"; 
	echo "`date`: $dir" >> $S; 
	du -hs $dir >> $S; echo "" >> $S; 
done < <(ls -d "$DIR"/*);
exit 0
