#'!/bin/bash
THING=$1
if [ -e "$THING" ]; then
btrfs property set "$THING" compression zlib
echo "$THING"
btrfs property get "$THING" compression
fi
