tail -f /mnt/ramfs/logs/newscache/newscache* | grep -Ei 'ERROR|Exception|Type|Desc|field'
