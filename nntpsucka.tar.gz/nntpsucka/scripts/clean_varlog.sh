
find /var/log -type f -name "*.1" -delete
find /var/log -type f -name "*.gz" -delete
