#!/bin/bash

# Clear rbenv variables before starting tmux
unset RBENV_VERSION
unset RBENV_DIR

tmux start-server;

cd /home/nntp-proxy

# Run on_project_start command.



  # Run pre command.
  
  
  # Run on_project_first_start command.
  

  # Create the session and the first window. Manually switch to root
  # directory if required to support tmux < 1.9
  TMUX= tmux new-session -d -s job-nntp-proxy -n shell01
  tmux send-keys -t job-nntp-proxy:0 cd\ /home/nntp-proxy C-m


  # Create other windows.
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:1 -n shell02
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:2 -n shell03
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:3 -n shell04
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:4 -n shell05
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:5 -n shell06
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:6 -n shell07
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:7 -n shell08
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:8 -n shell09
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:9 -n shell10
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:10 -n shell11
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:11 -n shell12
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:12 -n shell13
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:13 -n shell14
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:14 -n shell15
  tmux new-window -c /home/nntp-proxy -t job-nntp-proxy:15 -n shell16


  # Window "shell01"
  tmux send-keys -t job-nntp-proxy:0.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:0
  tmux select-layout -t job-nntp-proxy:0 tiled
  tmux send-keys -t job-nntp-proxy:0.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:0
  tmux select-layout -t job-nntp-proxy:0 tiled
  tmux send-keys -t job-nntp-proxy:0.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:0
  tmux select-layout -t job-nntp-proxy:0 tiled
  tmux send-keys -t job-nntp-proxy:0.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:0 tiled

  tmux select-layout -t job-nntp-proxy:0 
  tmux select-pane -t job-nntp-proxy:0.0


  # Window "shell02"
  tmux send-keys -t job-nntp-proxy:1.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:1
  tmux select-layout -t job-nntp-proxy:1 tiled
  tmux send-keys -t job-nntp-proxy:1.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:1
  tmux select-layout -t job-nntp-proxy:1 tiled
  tmux send-keys -t job-nntp-proxy:1.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:1
  tmux select-layout -t job-nntp-proxy:1 tiled
  tmux send-keys -t job-nntp-proxy:1.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:1 tiled

  tmux select-layout -t job-nntp-proxy:1 
  tmux select-pane -t job-nntp-proxy:1.0


  # Window "shell03"
  tmux send-keys -t job-nntp-proxy:2.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:2
  tmux select-layout -t job-nntp-proxy:2 tiled
  tmux send-keys -t job-nntp-proxy:2.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:2
  tmux select-layout -t job-nntp-proxy:2 tiled
  tmux send-keys -t job-nntp-proxy:2.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:2
  tmux select-layout -t job-nntp-proxy:2 tiled
  tmux send-keys -t job-nntp-proxy:2.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:2 tiled

  tmux select-layout -t job-nntp-proxy:2 
  tmux select-pane -t job-nntp-proxy:2.0


  # Window "shell04"
  tmux send-keys -t job-nntp-proxy:3.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:3
  tmux select-layout -t job-nntp-proxy:3 tiled
  tmux send-keys -t job-nntp-proxy:3.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:3
  tmux select-layout -t job-nntp-proxy:3 tiled
  tmux send-keys -t job-nntp-proxy:3.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:3
  tmux select-layout -t job-nntp-proxy:3 tiled
  tmux send-keys -t job-nntp-proxy:3.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:3 tiled

  tmux select-layout -t job-nntp-proxy:3 
  tmux select-pane -t job-nntp-proxy:3.0


  # Window "shell05"
  tmux send-keys -t job-nntp-proxy:4.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:4
  tmux select-layout -t job-nntp-proxy:4 tiled
  tmux send-keys -t job-nntp-proxy:4.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:4 tiled

  tmux select-layout -t job-nntp-proxy:4 
  tmux select-pane -t job-nntp-proxy:4.0


  # Window "shell06"
  tmux send-keys -t job-nntp-proxy:5.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:5
  tmux select-layout -t job-nntp-proxy:5 tiled
  tmux send-keys -t job-nntp-proxy:5.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:5
  tmux select-layout -t job-nntp-proxy:5 tiled
  tmux send-keys -t job-nntp-proxy:5.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:5
  tmux select-layout -t job-nntp-proxy:5 tiled
  tmux send-keys -t job-nntp-proxy:5.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:5 tiled

  tmux select-layout -t job-nntp-proxy:5 
  tmux select-pane -t job-nntp-proxy:5.0


  # Window "shell07"
  tmux send-keys -t job-nntp-proxy:6.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:6
  tmux select-layout -t job-nntp-proxy:6 tiled
  tmux send-keys -t job-nntp-proxy:6.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:6 tiled

  tmux select-layout -t job-nntp-proxy:6 
  tmux select-pane -t job-nntp-proxy:6.0


  # Window "shell08"
  tmux send-keys -t job-nntp-proxy:7.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:7
  tmux select-layout -t job-nntp-proxy:7 tiled
  tmux send-keys -t job-nntp-proxy:7.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:7 tiled

  tmux select-layout -t job-nntp-proxy:7 
  tmux select-pane -t job-nntp-proxy:7.0


  # Window "shell09"
  tmux send-keys -t job-nntp-proxy:8.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:8
  tmux select-layout -t job-nntp-proxy:8 tiled
  tmux send-keys -t job-nntp-proxy:8.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:8 tiled

  tmux select-layout -t job-nntp-proxy:8 
  tmux select-pane -t job-nntp-proxy:8.0


  # Window "shell10"
  tmux send-keys -t job-nntp-proxy:9.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:9
  tmux select-layout -t job-nntp-proxy:9 tiled
  tmux send-keys -t job-nntp-proxy:9.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:9
  tmux select-layout -t job-nntp-proxy:9 tiled
  tmux send-keys -t job-nntp-proxy:9.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:9
  tmux select-layout -t job-nntp-proxy:9 tiled
  tmux send-keys -t job-nntp-proxy:9.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:9 tiled

  tmux select-layout -t job-nntp-proxy:9 
  tmux select-pane -t job-nntp-proxy:9.0


  # Window "shell11"
  tmux send-keys -t job-nntp-proxy:10.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:10
  tmux select-layout -t job-nntp-proxy:10 tiled
  tmux send-keys -t job-nntp-proxy:10.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:10 tiled

  tmux select-layout -t job-nntp-proxy:10 
  tmux select-pane -t job-nntp-proxy:10.0


  # Window "shell12"
  tmux send-keys -t job-nntp-proxy:11.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:11
  tmux select-layout -t job-nntp-proxy:11 tiled
  tmux send-keys -t job-nntp-proxy:11.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:11
  tmux select-layout -t job-nntp-proxy:11 tiled
  tmux send-keys -t job-nntp-proxy:11.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:11
  tmux select-layout -t job-nntp-proxy:11 tiled
  tmux send-keys -t job-nntp-proxy:11.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:11 tiled

  tmux select-layout -t job-nntp-proxy:11 
  tmux select-pane -t job-nntp-proxy:11.0


  # Window "shell13"
  tmux send-keys -t job-nntp-proxy:12.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:12
  tmux select-layout -t job-nntp-proxy:12 tiled
  tmux send-keys -t job-nntp-proxy:12.1 pwd C-m

  tmux select-layout -t job-nntp-proxy:12 tiled

  tmux select-layout -t job-nntp-proxy:12 
  tmux select-pane -t job-nntp-proxy:12.0


  # Window "shell14"
  tmux send-keys -t job-nntp-proxy:13.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:13
  tmux select-layout -t job-nntp-proxy:13 tiled
  tmux send-keys -t job-nntp-proxy:13.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:13
  tmux select-layout -t job-nntp-proxy:13 tiled
  tmux send-keys -t job-nntp-proxy:13.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:13
  tmux select-layout -t job-nntp-proxy:13 tiled
  tmux send-keys -t job-nntp-proxy:13.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:13 tiled

  tmux select-layout -t job-nntp-proxy:13 
  tmux select-pane -t job-nntp-proxy:13.0


  # Window "shell15"
  tmux send-keys -t job-nntp-proxy:14.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:14
  tmux select-layout -t job-nntp-proxy:14 tiled
  tmux send-keys -t job-nntp-proxy:14.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:14
  tmux select-layout -t job-nntp-proxy:14 tiled
  tmux send-keys -t job-nntp-proxy:14.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:14
  tmux select-layout -t job-nntp-proxy:14 tiled
  tmux send-keys -t job-nntp-proxy:14.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:14 tiled

  tmux select-layout -t job-nntp-proxy:14 
  tmux select-pane -t job-nntp-proxy:14.0


  # Window "shell16"
  tmux send-keys -t job-nntp-proxy:15.0 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:15
  tmux select-layout -t job-nntp-proxy:15 tiled
  tmux send-keys -t job-nntp-proxy:15.1 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:15
  tmux select-layout -t job-nntp-proxy:15 tiled
  tmux send-keys -t job-nntp-proxy:15.2 pwd C-m

  tmux splitw -c /home/nntp-proxy -t job-nntp-proxy:15
  tmux select-layout -t job-nntp-proxy:15 tiled
  tmux send-keys -t job-nntp-proxy:15.3 pwd C-m

  tmux select-layout -t job-nntp-proxy:15 tiled

  tmux select-layout -t job-nntp-proxy:15 
  tmux select-pane -t job-nntp-proxy:15.0


  tmux select-window -t job-nntp-proxy:0
  tmux select-pane -t job-nntp-proxy:0.0

  if [ -z "$TMUX" ]; then
    tmux -u attach-session -t job-nntp-proxy
  else
    tmux -u switch-client -t job-nntp-proxy
  fi


    
# Run on_project_exit command.


