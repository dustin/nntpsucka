#!/bin/bash
mktorrent \
	-l 26 -v \
	-a udp://9.rarbg.to:2710/announce \
	-a udp://9.rarbg.me:2710/announce \
	-a udp://tracker.opentrackr.org:1337/announce \
	-a udp://tracker.internetwarriors.net:1337/announce \
	-a udp://exodus.desync.com:6969/announce \
	-a udp://tracker.cyberia.is:6969/announce \
	-a udp://3rt.tace.ru:60889/announce \
	-a http://5rt.tace.ru:60889/announce \
	-a udp://explodie.org:6969/announce \
	-a udp://p4p.arenabg.ch:1337/announce \
	-a http://p4p.arenabg.com:1337/announce \
	-a udp://tracker3.itzmx.com:6961/announce \
	-a http://open.acgnxtracker.com:80/announce \
	-a udp://tracker.zerobytes.xyz:1337/announce \
	-a udp://tracker.tiny-vps.com:6969/announce \
	-a udp://tracker.ds.is:6969/announce \
	-a udp://open.stealth.si:80/announce \
	-a udp://open.demonii.si:1337/announce \
	-a udp://retracker.lanta-net.ru:2710/announce \
	-a udp://opentracker.i2p.rocks:6969/announce \
	"$1"
exit $?

