#!/bin/bash
uptime
echo ""
echo -e "IOtop\n `iotop -o -b -n 1|head -1|tr '|' '\n'`";
echo ""
#ps aux|grep "^nntps"|grep python|tr -s ' '|sort -t" " -k3 -hr|head -9 |cut -d" " -f1,2,3,4,10,11,12,13,14,15
#ps aux|grep "^nntps"|grep python|tr -s " "|sort -t" " -k3 -hr|head -9|cut -d" " -f1,2,3,4,10,11,12,13,14,15
TOP=`top -b -n 1 | head -11|grep -E 'Cpu|KiB'`;
echo "$TOP"
echo "#"
echo "# Stats"
#echo "nntpsucka: `ps aux|grep python|grep sucka|grep -v grep|wc -l`";
echo "nntpsucka: `ps -u nntpsucka|grep python|wc -l`";
echo "out conns: `LC_ALL=en_US.UTF-8 netstat -an|grep :8080|grep ESTABLISHED|grep -v grep|wc -l`";
echo "newscache: `pidof newscache|wc -w`";
echo "rsyncjobs: `pidof rsync`";
ps a|grep rsync|grep -vEi 'grep|screen'|tr -s ' '|cut -d" " -f1,5,6,7,8,9,10,11,12,13,14,15,16
echo ""
echo "RAM: `du -hs /mnt/ramfs/newsdb/`"
echo "## System"
sensors|grep Core|cut -d"(" -f1
echo "NVME0 `smartctl -a /dev/nvme0|grep ^Temp`"
#vnstat -l
