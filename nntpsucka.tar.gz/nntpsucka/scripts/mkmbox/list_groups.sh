#!/bin/bash
# get groups from cachedir
cd /mnt/sdb/news/newscache
mv groups.list groups.list.$(date +%s).bak
find . -type d | sed 's/\.\///g' | sed 's/\//./g' > groups.list
