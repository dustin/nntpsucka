#!/bin/bash
# make mbox from .art* files
#
echo "usage: $0 symantec.support"

DIR="/mnt/sdb/news/newscache"
cd $DIR

workdir=$(echo $1 | sed 's/\./\//g')
cd "$workdir" || exit 1
pwd
group=$1
arts=$(find . -mindepth 1 -maxdepth 1 -type f -name ".art*"|wc -l)
mbox="$group.($arts).mbox"
while read file; do 
 #echo "$file"
 echo "From nobody `date`" >> "$mbox"
 cat "$file" >> "$mbox"
 echo -e "\n\n" >> "$mbox"
done< <(find . -mindepth 1 -maxdepth 1 -type f -iname ".art*"|sed 's/\.\///g'|sort -V)
gzip -fv -9 "$mbox"
du -hs "${mbox}.gz"
