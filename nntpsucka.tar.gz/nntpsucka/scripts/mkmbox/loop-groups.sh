#!/bin/bash

cd /mnt/sdb/news/newscache

while read group; do
 echo $group
 /scripts/mkmbox/make_mbox.sh $group
done< <(cat groups.list)
