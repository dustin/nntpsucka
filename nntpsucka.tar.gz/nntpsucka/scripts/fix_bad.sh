#!/bin/bash
cd /home/nntpsucka
MCACHE="/mnt/sdb/news"
CACHES="newscache"

while read file; do
 #echo $file
 MD5=`md5sum $file|cut -d" " -f1`
 while read line; do
  #echo $line
  GRP=`echo "$line"|cut -d" " -f1|cut -d"=" -f2`
  GRPP=`echo "$GRP"|tr '.' '/'`;
  ARTNUM=`echo "$line"|cut -d" " -f2|cut -d"=" -f2`
  ARTPATH=`echo "$line"|cut -d" " -f3|cut -d"=" -f2`;
  PGRP=`echo "$line"|cut -d" " -f4|cut -d"=" -f2`;
  # search file on caches
  for CACHE in $CACHES; do
   ARTFILE="$MCACHE/$CACHE/$PGRP";
   CDIR="$MCACHE/$CACHE/$GRPP";
   #echo "check $CDIR";
   if [ -e $CDIR ]; then
    if [ -f $ARTFILE ]; then
     echo "try fix bad: $ARTFILE"
     grep -E "error@error|msgid|fullusenet" $ARTFILE
     /scripts/fix_crlf.sh $ARTFILE
    else
     echo "not found: $ARTFILE";
    fi;
   fi;
  done;
 done < <(cat "$file");
 MDB=`md5sum $file|cut -d" " -f1`;
 if [ "$MDB" = "$MD5" ]; then
  cat "$file" >> "fixed/fixed.$file";
  rm "$file";
  wc -l  "fixed.$file";
 fi;
done < <(ls bad.*);
exit 0

