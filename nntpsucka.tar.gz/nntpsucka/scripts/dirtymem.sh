watch 'egrep "(Dirty|Writeback)" /proc/meminfo'
