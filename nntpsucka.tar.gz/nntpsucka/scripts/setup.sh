apt install vim stunnel haproxy mariadb-server vnstat tcpdump htop apache2 phpmyadmin inn2 vnstati python python-pip python-twisted python-mysqldb iftop
pip install requests
pip install pyOpenSSL
exit 0

mysql_secure_installation
echo "# add mysql user"
echo "CREATE USER 'newscache'@'%' IDENTIFIED BY 'newscache';"
echo "GRANT USAGE ON *.* TO 'newscache'@'%' IDENTIFIED BY PASSWORD '*E69A0ECCB6817DE64B7A9A40C7338E4BE54DDE5F';"
echo "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER ON \`newscache\`.* TO 'newscache'@'%';"
mysql -uroot
apt install arno-iptables-firewall
mkdir -p /usr/local/opt/newscache
chown news:news /usr/local/opt/newscache
chmod 770 /usr/local/opt/newscache

