
SIZE=`du -b $1 | cut -f1`
test $SIZE -eq 0 && echo "$1 size = 0" && rm -v $1 && exit 0

MSG="Message-ID: <nomsgidinheader-error`pwgen -s 18 |tr '[:upper:]' '[:lower:]'`@fullusenet.com>"
grep -i "^message-id:\ <" $1 > /dev/null
if [ $? -eq 1 ]; then 
 echo "Message-ID not found in $1"
 echo -e "$MSG\r\n" > $1.new 
 cat $1 >> $1.new 
 mv -v $1.new $1 
 exit $?
fi

# clears hex chars
# BE <be> 3/4
sed 's'/`printf "\xBE"`'//g' -i $1

# clears bad x-no-archive header
sed 's/orld\rx-no-archive/orld\r\nx-no-archive/g' -i $1
sed 's/orld\rX-No-Archive/orld\r\nX-No-Archive/g' -i $1
sed 's/\ wWorld/\ World/g' -i $1

# clears tabs
perl -pe 's/\010//g' -i $1

# clears "^M^M" with "^M^M"
sed ':a;N;$!ba;s/\r\r/\r/g' -i $1

# clears "^M>" with ">"
sed ':a;N;$!ba;s/\r>/>/g' -i $0


# clears "^M " with " "
sed ':a;N;$!ba;s/\r\ / /g' -i $1

# clears ^M[A-Za-z0-9]
sed ':a;N;$!ba;s/\r[A-Za-z0-9]/ /g' -i $1

# clears ^M"
sed ':a;N;$!ba;s/\r\"/ /g' -i $1

# clears ^M^M$
sed ':a;N;$!ba;s/\r\r$/\r$/g' -i $1

# clears ^M,
sed ':a;N;$!ba;s/\r,/\ ,/g' -i $1

# clears ^M?
sed ':a;N;$!ba;s/\r?/\ ?/g' -i $1

# clears ^M.
sed ':a;N;$!ba;s/\r\./\\./g' -i $1

# clears ^M!
sed ':a;N;$!ba;s/\r!/\ /g' -i $1

#clears ^M$
sed ':a;N;$!ba;s/\r\$]/\$/g' -i $1

# clears ^M>
sed ':a;N;$!ba;s/\r>/>/g' -i $1

# clears ^Mtab
sed ':a;N;$!ba;s/\r\t/\ /g' -i $1

# fix NUL CHAR ^@
sed '/\x00/d' -i $1
