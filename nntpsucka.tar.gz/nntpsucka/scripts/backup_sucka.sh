#!/bin/bash
FILE="/mnt/TOS3T1/suckacachebundle-`date | tr ' ' '-'`.tar.gz"
tar cfvz "$FILE" /scripts /home/nntpsucka /usr/local/opt/newscache* /usr/src/newscache*
du -hs "$FILE"
exit $?
