#!/bin/bash
DIR=$1
test -z $1 && echo "usage $0: DIR"
p7zip -k "$DIR" "$DIR.7z"
exit $?
