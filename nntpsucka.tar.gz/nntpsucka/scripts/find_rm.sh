find . -name "*.db" -delete -print
