du -hs * > sizes.txt
grep G sizes.txt
