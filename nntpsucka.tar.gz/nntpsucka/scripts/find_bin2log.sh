while read file; do DATA=` grep ybegin $file`; test $? -eq 0 && echo "$file:$DATA" >> bin.log; done < <(find . -name ".art*")
