#!/bin/bash
test -z $1 && echo "usage: $0 [.|/dir/path]" && exit 1
cd "$1" || exit 1
#mkdir -p .del
#test ! -e .del && echo "DIR .del not found!" && exit 1
B=0
N=0
while read file; do
 #grep ybegin "$file"
 DATA=`nice -n 19 grep -B999 --max-count=1 "^=ybegin\ " "$file"` > /dev/null
 if [ $? -eq 0 ]; then
  let B="B+1";
  echo "binaryfile: '$file' (B=$B N=$N)";
  echo "$DATA" | grep -v "^=ybegin" > "$file";
  #echo "$DATA" > "$file" &
  #echo "$file.new"
  #mv -v "$file.new" "$file";
  #exit
  #rm -v "$file";
  #test $B -gt 10000 && break;
 else
  let N="N+1"
 fi;
done < <(find . -type f -name ".art*")
echo "binary=$B normal=$N Dir=$1";
exit 0

