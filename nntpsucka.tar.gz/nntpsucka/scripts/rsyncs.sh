# rsync -va --progress /mnt/WDG2T1/newscache-text/comp /mnt/TOSH2T2/store/ --exclude=.db

# rsync --dry-run -vad --delete-after --progress /mnt/STB2T1/newscache-text/comp /mnt/TOSH2T2/store/

# rsync -va -progress /mnt/WDG2T1/newscache-text/ /mnt/ST4T1/store/ --exclude=comp/unix/advocacy --exclude=.db

# rsync -va /mnt/STB2T1/newscache-text/rec /mnt/STB2T1/newscache-text/sci /mnt/STB2T1/newscache-text/soc /mnt/STB2T1/newscache-text/misc /mnt/STB2T1/newscache-text/talk /mnt/STB2T1/newscache-text/linux /mnt/STB2T1/newscache-text/de /mnt/STB2T1/newscache-text/es /mnt/STB2T1/newscache-text/fr /mnt/STB2T1/newscache-text/free /mnt/STB2T1/newscache-text/it /mnt/WDG3T1/store/
