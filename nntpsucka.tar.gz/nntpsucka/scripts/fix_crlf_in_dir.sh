#/bin/bash
test -z $1 && echo "usage: $0 DIR" && exit 1
DIR=$1
test -e $DIR || exit 1
while read file; do
 #echo $file; 
 /scripts/fix_crlf.sh $file;
done < <(find $DIR -name ".art*")
#for file in `ls -a $DIR/.art*`; do echo $file; /scripts/fix_crlf.sh $file; done
