#!/bin/bash
(test -z $1 || test -z $2 || test -z $3) && echo "usage $0: LABEL file.iso /src/dir" && exit 1
LABEL=$1
ISO=$2
DIR=$3
test -e "$ISO" && echo "Error: $ISO exists!" && exit 1
xorriso -as mkisofs -v -J -r -V "$LABEL" -o "$ISO" "$DIR"
test $? -eq 0 || exit 1
xorriso -as cdrecord -v dev=/dev/sr0 -dao "$ISO"
exit $?
