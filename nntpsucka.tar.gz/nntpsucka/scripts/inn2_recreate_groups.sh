while read line; do echo "$line"; ctlinnd rmgroup $line; ctlinnd newgroup $line; done < <(cat gmane.list|grep gmane)
