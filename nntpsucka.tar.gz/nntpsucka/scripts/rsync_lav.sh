#!/bin/bash
while read dir; do 
	rsync -va -L --progress "$dir" root@209.141.55.183:/var/cache/newscache1/newscache-cache/; sleep 1; 
done < <(find . -mindepth 1 -maxdepth 1 -type d)
