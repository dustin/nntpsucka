#!/bin/bash
test -z $1 && echo "usage: $0 [newscache-text|newscache-50k]" && exit 1
HOSTNAME=lav1.fullusenet.com
ROOTDIR=/var/cache/$1
DONEFILE="/home/nntpsucka/newsdb.local/rsync_done.$1"
START=`date`
RSYNCJ=0
RSYNCM=9
cd $ROOTDIR
for dir1 in `ls`; do
 echo "$dir1/";
 cd $ROOTDIR/$dir1
 for dir2 in `ls`; do
  grep -E ".*$dir1\/$dir2:.*" "$DONEFILE" 2>/dev/null && continue
  echo "$dir1/$dir2";
  RSYNC="rsync -vaz --progress --exclude=.db $ROOTDIR/$dir1/$dir2 root@$HOSTNAME:/var/cache/newscache1/$1/$dir1/"
  echo "$RSYNC"
  #sleep 9
  $RSYNC
  if [ $? -eq 0 ]; then
   echo "==$dir1/$dir2:`date +%s`" >> $DONEFILE
  fi;
  sleep 1
 done;
 sleep 1;
done;
END=`date`
echo "start: $START"
echo "ended: $END"
exit 0
