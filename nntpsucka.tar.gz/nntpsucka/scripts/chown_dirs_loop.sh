#!/bin/bash
while read dir; do /scripts/chown_dirs.sh $dir; done < <(ls)
