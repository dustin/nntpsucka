#/bin/bash
FILE=forcedList.$1
test -z $1 && echo "usage: $0 linux" && exit 1
test ! -f $FILE && echo "$FILE not found" && exit 1
rm newscache_$1.perm.conf
for line in `cut -d"^" -f2 $FILE |cut -d"\\\" -f1`; do 
	echo -n "$line.*," >> newscache_$1.perm.conf; 
done
cat newscache_$1.perm.conf
echo ""
echo "cat newscache_$1.perm.conf"
