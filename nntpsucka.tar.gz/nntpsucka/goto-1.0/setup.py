from distutils.core import setup
setup(name="goto",
      version="1.0",
      py_modules=["goto"])
