while true; do ./fix_bad.sh; sleep 2; done 2>/dev/null
