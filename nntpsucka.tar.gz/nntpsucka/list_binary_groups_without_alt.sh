grep -E "bin" list-2019-thecubenet-clean.txt |grep -v "^alt" | sort -t" " -k2 -gr > list_binary_groups_without_alt.txt
