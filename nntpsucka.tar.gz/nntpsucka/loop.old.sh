#!/bin/bash
conf=$1
while true; do 
 T1=`date +%s`
 ./nntpsucka.py sucka_$conf.conf;
 T2=`date +%s`
 let DIFF="T2 - T1"
 if [ $DIFF -lt 15 ]; then
  sleep=1800
  test $1 = "news" && sleep=3600
  test $1 = "gmane" && sleep=3600
  test $1 = "humanities" && sleep=3600
  test $1 = "at" && sleep=3600
  test $1 = "linux" && sleep=3600
 else
  sleep=3	 
 fi
  echo "sleeping $sleep s..."; sleep $sleep; 
done;
