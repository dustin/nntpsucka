BIG8="at comp de es esp fr free gmane humanities it linux misc news rec sci soc talk"
for group in $BIG8; do
./loop.sh $group &
done;
