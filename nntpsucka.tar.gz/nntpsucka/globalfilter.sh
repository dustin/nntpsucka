

rm -v globalfilter.new
for line in `sort -u globalfilter2.txt|sed 's/\./\\\./g'`; do echo "^$line" >> globalfilter.new; done
cat globalfilter.new
wc -l globalfilter.new
