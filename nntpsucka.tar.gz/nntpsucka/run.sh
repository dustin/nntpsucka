./kill.sh $1; sleep 1;
#/scripts/fix_bad.sh
./start.sh $1; sleep 3; 
tail -f *_$1.log
