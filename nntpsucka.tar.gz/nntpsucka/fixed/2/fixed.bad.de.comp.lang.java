group=de.comp.lang.java num=57861 messid=<33r0ptF4437knU1@individual.net> pgrp=de/comp/lang/java/.art57861
