group=linux.debian.maint.java num=984 messid=<6cgIn-5ZT-5@gated-at.bofh.it> pgrp=linux/debian/maint/java/.art984
group=linux.debian.maint.java num=994 messid=<6dAYq-1Hw-29@gated-at.bofh.it> pgrp=linux/debian/maint/java/.art994
group=linux.debian.maint.java num=1233 messid=<6SlyQ-1In-39@gated-at.bofh.it> pgrp=linux/debian/maint/java/.art1233
