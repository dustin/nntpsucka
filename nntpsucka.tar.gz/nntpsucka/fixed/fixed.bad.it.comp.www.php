group=it.comp.www.php num=25213 messid=<b0vNc.60195$5D1.2934528@news4.tin.it> pgrp=it/comp/www/php/.art25213
