#!/bin/bash
FILE=groups_with_5M-50M_articles.txt
while read line; do
	 WRITE=`echo $line |cut -d"*" -f1`
	  echo "${WRITE}\." >> "${FILE}.list"
done < <(cat $FILE)
echo "$FILE.list"
wc -l "$FILE.list"

