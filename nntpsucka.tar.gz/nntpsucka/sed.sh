sed 's/news-nl\.newshosting\.com/127\.0\.0\.1/g' -i *.conf
sed 's/port=119/port=62104/g' -i *.conf
sed 's/username=nntptest1@hacker\.tl/username=p12010909/g' -i *.conf
sed 's/password=Begei6Bo/password=59yv85dg/g' -i *.conf

