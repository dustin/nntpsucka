#!/bin/bash
test -z $1 && echo "usage $0: group" && exit 1
while true; do ./start.sh $1; sleep 5; done
