#!/bin/bash

cd /home/nntpsucka
#cd /mnt/container0/home/nntpsucka

if test -z ${1}; then echo "usage $0 group"; exit 1; fi

pidfile="nntpsucka_${1}.pid"
RUN=0
if test -f ${pidfile}; then
 pid=`cat ${pidfile}`;
 for pids in `pidof python`; do
  if [ $pid -eq $pids ]; then RUN=1; fi;
 done;
 #ps aux |grep "${pid}"|grep python|grep "${1}\.conf|grep -v grep" > /dev/null;
 #RUN=$?
 if [ $RUN -gt 0 ]; then
  echo "$1 nntpsucka_${1}.pid ${pid} runnning!"; 
  tail "sucka"*"_${1}.log";
  exit 1;
 fi;
fi;

#exit 2


test -x filter.sh && ./filter.sh ${1}
test -f doneList.${1} && sort -u doneList.${1} > doneList.${1}.tmp && mv -v doneList.${1}.tmp doneList.${1}

rm -v *"_${1}.log"
#gzip *_${1}.log
#mkdir -p log.old/${1}
#mv -v *_${1}.log.gz log.old/${1}/

LOGFILE="sucka`date +%s`_${1}.log"
if test -f "sucka_${1}.conf"; then
 ./nntpsucka.py "sucka_${1}.conf" > ${LOGFILE} &
 if [ "$2" = "log" ]; then
  sleep 5s
  tail -f "${LOGFILE}";
 else
  echo "tail -f ${LOGFILE}";
 fi
 #sleep 5 && tail "${LOGFILE}";
 exit 0
else
 echo "sucka_${1}.conf not found"
 exit 1
fi;


exit 1

#tail -f "${LOGFILE}";
