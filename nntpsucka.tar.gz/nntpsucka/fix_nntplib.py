# rm /usr/lib/python2.7/nntplib.pyc

    def getline(self):
	....
	....
        line = self.file.readline()
        #line = self.file.readline(_MAXLINE + 1)
        #if len(line) > _MAXLINE:
        #    raise NNTPDataError('line too long = %s' % (len(line)))

