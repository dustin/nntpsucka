kill `cat nntpsucka_$1.pid`
#kill `ps aux|grep sucka_$1|grep python|grep -v grep|tr -s ' ' |cut -d" " -f2`
