#!/bin/bash
grep workers= *.conf
echo -n "sum of workers: "
grep workers= *.conf | awk 'BEGIN {FS = "="} ; {sum+=$2} END {print sum}'

#grep workers *.conf |cut -d":" -f1|cut -d"_" -f2|cut -d"." -f1

exit $?
