grep ^alt\. list-2019-thecubenet.txt|grep -v "^alt\.bin"| awk 'BEGIN {FS = " "} ; {sum+=$2} END {print sum}'
