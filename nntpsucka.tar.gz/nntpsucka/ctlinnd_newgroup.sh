for group in `cat linux.txt`; do echo "$group " && ctlinnd newgroup $group; done
